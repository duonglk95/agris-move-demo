<?php
/**
 * Plugin Name: AgriS MOVE – Dữ liệu Vào vụ (chạy 1 lần)
 * Description: Tạo trang Sự kiện, mini-site Vào vụ (Pit Crew, Khoảnh khắc đội mình), video teaser, ảnh thư tay và ảnh dự thi mẫu. Kích hoạt một lần rồi xoá plugin.
 * Version: 1.0
 */
register_activation_hook( __FILE__, 'agm_seed_run' );

function agm_seed_media( $file, $parent = 0 ) {
	require_once ABSPATH . 'wp-admin/includes/image.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	$found = get_posts( array( 'post_type' => 'attachment', 'name' => sanitize_title( pathinfo( $file, PATHINFO_FILENAME ) ), 'numberposts' => 1, 'fields' => 'ids' ) );
	if ( $found ) { return $found[0]; }
	$tmp = wp_tempnam(); copy( __DIR__ . '/media/' . $file, $tmp );
	$id = media_handle_sideload( array( 'name' => $file, 'tmp_name' => $tmp ), $parent );
	return is_wp_error( $id ) ? 0 : $id;
}

function agm_seed_page( $slug, $title, $tpl, $content, $parent = 0, $order = 0, $excerpt = '' ) {
	$p = get_page_by_path( $parent ? get_post_field( 'post_name', $parent ) . '/' . $slug : $slug );
	$data = array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $title, 'post_name' => $slug, 'post_content' => $content, 'post_parent' => $parent, 'menu_order' => $order, 'post_excerpt' => $excerpt );
	if ( $p ) { $data['ID'] = $p->ID; $id = wp_update_post( $data ); } else { $id = wp_insert_post( $data ); }
	update_post_meta( $id, '_wp_page_template', $tpl );
	return $id;
}

function agm_seed_run() {
	@set_time_limit( 300 );
	$banner = agm_seed_media( 'vao-vu-action.jpg' );
	$video  = agm_seed_media( 'vao-vu-teaser.mp4' );

	agm_seed_page( 'su-kien', 'Sự kiện', 'page-events.php', '' );
	$hub = agm_seed_page( 'vao-vu', 'Vào vụ 2026–2027', 'page-event-hub.php', 'Mùa vụ mới bắt đầu rồi! Chọn một hoạt động để gửi lời động viên đến những đồng đội đang ngày ngày bám ruộng, bám ca.' );
	set_post_thumbnail( $hub, $banner );
	update_post_meta( $hub, 'menu_label', 'Vào vụ' );
	update_post_meta( $hub, 'hero_video', wp_get_attachment_url( $video ) );
	agm_seed_page( 'pit-crew', 'Đăng ký Pit Crew', 'page-pitcrew.php', 'Cùng Pit Crew theo chân đoàn HO đến các nhà máy và vùng nguyên liệu để tiếp sức cho đồng đội trong mùa vụ này. Chọn chuyến đi bạn muốn tham gia và gửi đăng ký. Ban tổ chức sẽ xét chọn và thông báo kết quả đến bạn.', $hub, 0, 'Cùng đoàn HO ra tận nhà máy và vùng nguyên liệu, tiếp sức cho đội vào vụ.' );
	$ct = agm_seed_page( 'khoanh-khac', 'Khoảnh khắc đội mình', 'page-contest.php', 'Mùa vụ là lúc cả AgriS cùng vào việc. Người bám ruộng từ sớm, người đứng máy xuyên ca, người chạy từng chuyến xe mía về nhà máy, người mang sản phẩm đến tay khách hàng, và những đồng đội lặng lẽ hỗ trợ phía sau. Hãy bắt lại những khoảnh khắc đội mình cùng nhau làm nên mùa vụ, từ ruộng mía, nhà máy, kho hàng, thị trường đến văn phòng. Những bức ảnh đạt giải sẽ được dùng trong các ấn phẩm truyền thông của Công ty.', $hub, 1 );

	// event card on the homepage
	$ev = get_posts( array( 'post_type' => 'su_kien', 'title' => 'Vào vụ 2026–2027', 'numberposts' => 1, 'post_status' => 'any' ) );
	$eid = $ev ? $ev[0]->ID : wp_insert_post( array( 'post_type' => 'su_kien', 'post_status' => 'publish', 'post_title' => 'Vào vụ 2026–2027' ) );
	foreach ( array( '_agm_at' => '2026-11-15T07:00', '_agm_end' => '2027-03-31T23:59', '_agm_page' => $hub, '_agm_place' => 'Mùa vụ 2026–2027' ) as $k => $v ) { update_post_meta( $eid, $k, $v ); }
	set_post_thumbnail( $eid, $banner );

	// postcard library
	if ( ! get_posts( array( 'post_type' => 'anh_buu_thiep', 'numberposts' => 1, 'fields' => 'ids' ) ) ) {
		foreach ( json_decode( file_get_contents( __DIR__ . '/media/photos.json' ), true ) as $p ) {
			$id = wp_insert_post( array( 'post_type' => 'anh_buu_thiep', 'post_status' => 'publish', 'post_title' => $p['title'], 'menu_order' => $p['order'] ) );
			set_post_thumbnail( $id, agm_seed_media( $p['file'] ) );
			update_post_meta( $id, '_agm_author', $p['author'] ); update_post_meta( $id, '_agm_place', $p['place'] );
		}
	}

	// sample contest entries (delete before the real contest opens)
	if ( ! get_posts( array( 'post_type' => 'anh_du_thi', 'numberposts' => 1, 'fields' => 'ids', 'post_status' => 'any' ) ) ) {
		global $wpdb;
		$votes = $wpdb->prefix . 'amv_votes';
		foreach ( json_decode( file_get_contents( __DIR__ . '/media/contest.json' ), true ) as $i => $e ) {
			$id = wp_insert_post( array( 'post_type' => 'anh_du_thi', 'post_status' => 'publish', 'post_title' => $e['title'], 'post_content' => $e['desc'] ) );
			set_post_thumbnail( $id, agm_seed_media( $e['frame'], $id ) );
			foreach ( array( '_agm_page' => $ct, '_agm_raw' => agm_seed_media( $e['raw'], $id ), '_agm_author' => $e['author'], '_agm_place' => $e['place'], '_agm_center' => $e['center'], '_agm_ip' => 'demo' ) as $k => $v ) { update_post_meta( $id, $k, $v ); }
			for ( $n = 0; $n < (int) $e['love']; $n++ ) {
				$wpdb->insert( $votes, array( 'employee_id' => 900000 + $n, 'mover_id' => $id, 'ip' => 'demo', 'created_at' => current_time( 'mysql' ) ) );
			}
		}
	}
	update_option( 'agm_seed_done', current_time( 'mysql' ) );
}
